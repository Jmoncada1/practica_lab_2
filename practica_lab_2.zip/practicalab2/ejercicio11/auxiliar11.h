//
// Created by jamli on 28/07/2022.
//

#ifndef EJERCICIO11_AUXILIAR11_H
#define EJERCICIO11_AUXILIAR11_H
void mostrarCine();
void Menu();
void iniciarCine();
bool reservarPuesto(int filas, int puestos);

void Menu(){

    cout<<"BIENVENIDO A MOCADA CINES "<<endl<<"¿que operacion desea realizar?"<<endl;
    cout<<"opcion 0 para salir"<<endl;
    cout<<"opcion 1 para ver la ocupacion de la sala"<<endl;
    cout<<"opcion 2 para reservar ";
}
void mostrarCine(){
    for(int i=0; i<filas; i++){
        cout<<"("<<i<<")";
        for(int j=0; j<puestos; j++){
            cout<<"["<<salaCine[i][j]<<"]";
        }
        cout<<endl;
    }

}
void iniciarCine(){
    for(int i=0; i<filas; i++) {
        for (int j = 0; j < puestos; j++) {
            salaCine[i][j];
        }
    }
}
bool reservarPuesto(int filas, int puestos){
    if(salaCine[filas][puestos]==0){
        salaCine[filas][puestos]=1;
        cout<<"el puesto se reservo correctamente"<<endl;
        return true;
    }
    else{
        cout<<"el puesto ya se encuentra reservado "<<endl;
        return false;
    }
}

#endif //EJERCICIO11_AUXILIAR11_H
