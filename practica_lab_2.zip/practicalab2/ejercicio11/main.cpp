/*Escribe un programa que permita manejar las reservas de asientos en una sala de cine, estos están organizados en 15 filas con 20 (asientos)
cada una. El programa debe mostrar una representación de la sala, que indique qué asientos están disponibles y cuales se encuentran reservados.
Además, debe permitir realizar reservas o cancelaciones al ingresar la fila (letras A-O) y el número del asiento (números 1-20).*/


#include <iostream>
#include <auxiliar11.h>
using namespace std;
int filas=10;
int puestos=8;
int salaCine [12][20];

void mostrarCine();
void Menu();
void iniciarCine();
bool reservarPuesto(int filas, int puestos);
int main() {
    int opcion=0;

    do{
        Menu();
        cout<<"elige opcion de la tarea que deseas realizar "<<endl;
        cin>>opcion;

        switch(opcion) {
            case 0:
                cout << "saliendo del programa" << endl;
                break;
            case 1:
                mostrarCine();
                break;
            case 2:
                do{
                    cout<<"ingrese el numero de la fila que desea reservar: "<<endl;
                    cin>>filas;

                    cout<<"ingrese el numero del puesto en la fila que desea reservar: "<<endl;
                    cin>>puestos;

                }while(reservarPuesto(filas,puestos)==false);
        }
    }while(opcion !=0);
    return 0;
}
/*void Menu(){
    cout<<"BIENVENIDO A MOCADA CINES "<<endl<<"¿que operacion desea realizar?"<<endl;
    cout<<"opcion 0 para salir"<<endl;
    cout<<"opcion 1 para ver la ocupacion de la sala"<<endl;
    cout<<"opcion 2 para reservar ";
}
void mostrarCine(){
    for(int i=0; i<filas; i++){
        cout<<"("<<i<<")";
        for(int j=0; j<puestos; j++){
            cout<<"["<<salaCine[i][j]<<"]";
        }
        cout<<endl;
    }

}
void iniciarCine(){
    for(int i=0; i<filas; i++) {
        for (int j = 0; j < puestos; j++) {
            salaCine[i][j];
        }
    }
}
bool reservarPuesto(int filas, int puestos){
    if(salaCine[filas][puestos]==0){
        salaCine[filas][puestos]=1;
        cout<<"el puesto se reservo correctamente"<<endl;
        return true;
    }
    else{
        cout<<"el puesto ya se encuentra reservado "<<endl;
        return false;
    }
}
