/*Un cuadrado mágico es una matriz de números enteros sin repetir, en la que la suma de los números en cada columna,
cada fila y cada diagonal principal tienen como resultado la misma constante. Escribe un programa que permita al
usuario ingresar una matriz cuadrada, imprime la matriz y verifica si la matriz es un cuadrado mágico.*/

#include <iostream>
using namespace std;

const int numMax = 5;
int main() {

    int N;
    cout<<"por favor ingresa el numero de la matriz: "<<endl;
    cin>>N;
    if(N<=1 || N>numMax){
        cout<<"dimension no valida "<<endl;

    }

    return 0;
}


int M[numMax][numMax];
for(int i=0;i<N;i++){
    for(int j = 0;j<N;j++){
        cout<<"M ["<<i+1<<" , "<<j+1<<" ]= "<<endl;
        cin>>M[i][j];

    }
}

int numMagic =0;
for(int j=0;j<N;j++){
    numMagic+= M[0][j];

}
int sumDiag1=0, sumDiag2=0;

for(int i=0;i<N;i++){
    int sumFil=0, sumCol=0;
    for(int j=0;j<N;j++){
        sumFil+=M[i][j];
        sumCol+=M[j][i];
    }
    if(sumFil != numMagic || sumCol != numMagic){
        cout<<"No es un cuadrado magico "<<endl;
        return 0;
    }
    sumDiag1 += M[i][i];
    sumDiag2 += M[N-1-i][N-1-i];

}
if(sumDiag1 != numMagic || sumDiag2 != numMagic){
    cout<<"No es un cuadrado magico "<<endl;
    return 0;

}
else{
    cout<<"es un cuadrado magico "<<endl;
    return 0;

}

