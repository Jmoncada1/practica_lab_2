//
// Created by jamli on 20/07/2022.
//

#ifndef TEORIA_AUXILIAR_H
#define TEORIA_AUXILIAR_H

short **problema14() {
    for (int fil = 0; fil < 5; fil++) {
        for (int col = 0; col < 5; col++) {
            int mat2[fil][col];
            int mat[fil][col]
            mat2[fil][col][fil][col] = mat[fil][col];
        }
    }

//funcion para rotar la matriz 180 grados
    void rotate_180(short **mat2, short **mat3){
        for (int fil = 0; fil < 5; fil++) {
            for (int col = 0; col < 5; col++) {
                mat3[fil][col] = mat2[fil][col];
            }
        }

    }
//funcion para rotar la matriz 270 grados
    void rotate_270(short **mat3, short **mat4){
        for (int fil = 0; fil < 5; fil++) {
            for (int col = 0; col < 5; col++) {
                mat4[fil][col] = mat3[fil][col];
            }
        }

    }
}
#endif //TEORIA_AUXILIAR_H