/*Elabora un programa que llene una matriz 5x5 con los números del 1 al 25 y la imprima, luego imprime la matriz rotada 90, 180 y 270 grados.
*/
#include <iostream>
#include "auxiliar.h"

using namespace std;
short **problema14()

int main() {

    short **problema14(){

        short ***mat;
        mat = new short **[4];

        for (int i = 0; i < 4; i++) {
            mat[i] = new short *[5];
            for (int j = 0; j < 5; j++) {
                mat[i][j] = new short[5];
                cout << "["<<mat[i][j]<<"]"<<endl;
            }

        }
        for (int fil = 0; fil < 5; fil++) {
            for (int col = 0; col < 5; col++) {
                mat[0][fil][col] = 5 * fil + col + 1;
                cout << "[" << mat[0][fil][col] << "]" << endl;
            }
        }
        void rotate_180(short **mat2 short **mat3){
            cout<<"la matriz rotada es: "<<endl;
            cout << "["<<mat2<<"]"<<endl;
        }
        void rotate_270(short **mat3 short **mat4){
            cout<<"la matriz rotada es: "<<endl;
            cout << "[" << mat3 << "]" << endl;
        }
    }
    return 0;
}

